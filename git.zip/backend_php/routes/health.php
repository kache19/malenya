<?php
echo json_encode(['status' => 'ok', 'timestamp' => date('c')]);
?>